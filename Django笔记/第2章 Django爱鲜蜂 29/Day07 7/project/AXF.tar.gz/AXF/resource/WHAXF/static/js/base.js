$(function () {
    // 屏幕宽度的十分之一 作为fontSize的大小
    document.documentElement.style.fontSize = innerWidth / 10 + "px";
})