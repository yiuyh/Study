$(document).ready(function(){
    document.documentElement.style.fontSize = innerWidth / 10 + "px";
})