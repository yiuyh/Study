from django.shortcuts import render
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.viewsets import ModelViewSet

from App.models import Game
from App.serializers import GameSerializer


class GamesView(ListCreateAPIView):

    serializer_class = GameSerializer

    queryset = Game.objects.all()


class GameView(RetrieveUpdateDestroyAPIView):

    serializer_class = GameSerializer

    queryset = Game.objects.all()


class GameModelViewSet(ModelViewSet):

    serializer_class = GameSerializer

    queryset = Game.objects.all()