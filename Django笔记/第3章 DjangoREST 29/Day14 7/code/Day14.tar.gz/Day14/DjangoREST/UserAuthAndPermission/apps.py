from django.apps import AppConfig


class UserauthandpermissionConfig(AppConfig):
    name = 'UserAuthAndPermission'
