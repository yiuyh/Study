from django.apps import AppConfig


class RestserializerConfig(AppConfig):
    name = 'RESTSerializer'
