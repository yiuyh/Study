from django.apps import AppConfig


class CbvConfig(AppConfig):
    name = 'CBV'
